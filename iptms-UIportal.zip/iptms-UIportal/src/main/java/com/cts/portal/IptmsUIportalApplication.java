package com.cts.portal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IptmsUIportalApplication {

	public static void main(String[] args) {
		SpringApplication.run(IptmsUIportalApplication.class, args);
	}

}
