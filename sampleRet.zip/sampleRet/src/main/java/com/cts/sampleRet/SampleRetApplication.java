package com.cts.sampleRet;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SampleRetApplication {

	public static void main(String[] args) {
		SpringApplication.run(SampleRetApplication.class, args);
	}

}
