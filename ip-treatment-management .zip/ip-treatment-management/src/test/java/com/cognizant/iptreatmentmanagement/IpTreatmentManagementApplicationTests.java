package com.cognizant.iptreatmentmanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IpTreatmentManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
