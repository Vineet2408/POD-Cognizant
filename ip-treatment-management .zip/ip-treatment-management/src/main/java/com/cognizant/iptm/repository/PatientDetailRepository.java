package com.cognizant.iptm.repository;

import org.springframework.data.repository.CrudRepository;

import com.cognizant.iptm.model.PatientDetail;

public interface PatientDetailRepository extends CrudRepository<PatientDetail, Long>{

}
