package com.cognizant.iptm.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.springframework.stereotype.Component;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Component
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class PatientDetail {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long patientId;
	private String name;
	private int age;
	private String treatmentPackage;
	private String ailment;
	private Date treatmentCommencementDate;

	@Override
	public String toString() {
		return "PatientDetail [patientId=" + patientId + ", name=" + name + ", age=" + age + ", treatmentPackage=" + treatmentPackage
				+ ", ailment=" + ailment + ", treatmentCommencementDate=" + treatmentCommencementDate + "]";
	}

}
