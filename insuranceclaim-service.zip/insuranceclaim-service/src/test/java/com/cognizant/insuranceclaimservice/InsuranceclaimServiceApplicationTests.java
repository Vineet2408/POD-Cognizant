package com.cognizant.insuranceclaimservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InsuranceclaimServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
