package com.cts.authorization;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IptmsAuthorizationApplicationTests {

	@Test
	void contextLoads() {
	}

}
